
# P L Mahesh — Portfolio (Static HTML)

Files in this folder:
- index.html  — main page
- styles.css — styling
- script.js  — small JS for interactions
- README.md  — this file

How to use:
1. Unzip the folder (if zipped) or open `index.html` directly in your browser.
2. Replace placeholder links and email address in the Contact section:
   - mailto:your-email@example.com
   - GitHub / LinkedIn links
3. To host online later: you can upload the folder to GitHub and enable GitHub Pages, or deploy to Netlify/Vercel.
4. If you want a downloadable resume or extra pages, tell me and I will add them.

Made for: P L Mahesh — Junior Software Developer
Technologies used: HTML, CSS, JavaScript
